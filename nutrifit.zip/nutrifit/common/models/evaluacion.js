'use strict';

module.exports = function(Evaluacion) {

};

'use strict';

module.exports = function(Actividad) {

};

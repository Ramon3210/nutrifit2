'use strict';

module.exports = function(Paciente) {

};

'use strict';

module.exports = function(Comida) {

};
